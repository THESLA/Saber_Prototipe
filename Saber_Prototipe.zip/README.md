	Proyecto Saber_prototipe
	Mas informacion : Tecnico@codigo0.net

INTRODUCCIÓN



La eficiencia en las labores cotidianas de las instituciones hoy en día, están muy ligadas al correcto uso de las tecnologías de la información y comunicación (TIC); las instituciones Educactivas no pueden ser ajenas a está realidad y siempre en sus procesos se encuentra inmersa la tecnología como medio de apoyo, proyección, divulgación o herramienta. El implementar esas tecnologías sin tenerlas debidamente interconectadas hacen que algunos procesos se entorpezcan, en está propuesta daremos soporte al proceso de aprendizaje, uso de herramientas TIC y fortalecimiento como un Departamento abanderado en el uso de las Tecnologías de la Información y Comunicación en la educación.

“Las Instituciones Educativas (las IEs), estan limitadas por infraestructura tecnologica y conectividad” (Tomado de las reflexiones del Foro educativo Departamental 2015), si bien el Estado ha hecho parte de la tarea, vemos muchas falencias y ellas repercuten en los resultados de las pruebas a nivel regional y nacional, con puntajes por debajo de la media, bachilleres sin nortes fijos y mucha deserción estudiantil.

Otro factor es que nestro Departamento se ha visto relegado tecnologicamente, con conexiones de baja calidad, donde en las capitales del Pais vemos conexiones a internet de minímo 4 MB, y nuestro Arauca llegar a tener 4 MB de econexión en casa es una utopía; exigir a los estudiantes labores virtuales, es poco fructífero.

Así, la clave consiste en empezar a considerar la interactividad vía intranets como un nuevo proceso eduactivo creando contenido colectivo a través de elementos de aprendizaje virtual, redes sociales educativas, plataformas de entrenamiento Pruebas Saber, sitios locales de divulgación de información.

Muchos docentes, tutores, coordinadores y demás personas que rodean la educación de nuestos jovenes araucanos, poseen grandes iniciativas, documentos, talleres, libros, videos, audios, entre otros grandes elementos de fortalecimiento educativo; pero se quedan cortos, ni siquiera de impacto local, escasamente llega a unas pocas aulas y el resto queda en total desconocimiento de tal material.

En las siguientes páginas se plasma una estrategia Tecnologico-educativa donde se busca amplificar el acceso a la información que el docente tiene en cada área; fortalecer los procesos de aprendizaje por medio de test y practicas en linea; implementar herramientas TIC ideal para cada I.E. y reforzar la comunicación institucional.
