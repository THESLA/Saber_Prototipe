var app = null;
(function () {
    "use strict";

    app = angular.module("saber_prot",
                            ['ngRoute', 'ngCookies']);


}());