(function () {
    "use strict";
    angular
        .module("common.services", ["ngResource"])
        .constant("appSettings",
        {
            //serverPath: "http://localhost:50348"
            serverPath: "http://localhost:90"
        });

}());