jQuery( document ).ready(function( $ ) {
	// Make an instance of two and place it on the page.



});

