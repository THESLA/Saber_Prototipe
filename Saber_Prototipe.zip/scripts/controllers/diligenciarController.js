(function () {
    'use strict';

    var controller = app.controller('diligenciarController', diligenciarController);
    //angular.module('productManagement')
    //    .controller('welcome', welcome);

    diligenciarController.$inject = [ '$scope'];
    function diligenciarController($scope) {


    }

})();