(function () {
    'use strict';

    var controller = app.controller('menuController', menuController);
    //angular.module('productManagement')
    //    .controller('welcome', welcome);

    menuController.$inject = [ '$scope'];
    function menuController($scope) {


    }

})();
