(function () {
    'use strict';

    var controller = app.controller('homeController', homeController);
    //angular.module('productManagement')
    //    .controller('welcome', welcome);

    homeController.$inject = [ '$scope'];
    function homeController($scope) {


    }

})();
