(function () {
    'use strict';

    var controller = app.controller('ayudaController', ayudaController);
    //angular.module('productManagement')
    //    .controller('welcome', welcome);

    ayudaController.$inject = [ '$scope'];
    function ayudaController($scope) {


    }

})();